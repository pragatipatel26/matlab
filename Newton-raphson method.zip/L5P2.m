x=[0.1;0.1;0.1;0.1];
tol=1e-4;
nonlinearnewtonraphson(x,tol)