x=0.01;
tolf=1e-4;
tolx=1e-4;
x=nonlinearnewton(x,tolx,tolf)