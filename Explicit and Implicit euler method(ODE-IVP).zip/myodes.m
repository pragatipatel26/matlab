function df=myodes(t,x)
k=0.1;
df=k*x;
